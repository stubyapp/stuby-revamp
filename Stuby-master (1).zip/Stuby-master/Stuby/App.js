import firebase from 'react-native-firebase';
import AppNavigator from './src/config/routes';
import React from 'react';
export default class App extends React.Component {
  constructor() {
    super();
    this.state = {};
  }
  async componentDidMount() {
    // TODO: You: Do firebase things
    // const { user } = await firebase.auth().signInAnonymously();
    // console.warn('User -> ', user.toJSON());

    // await firebase.analytics().logEvent('foo', { bar: '123'});
  }

  render() {
    return (
      <AppNavigator />
    )
  }
}
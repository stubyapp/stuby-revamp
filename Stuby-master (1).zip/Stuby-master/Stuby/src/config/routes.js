import React from 'react'
import { View, Text } from 'react-native'
import { createAppContainer } from 'react-navigation'
import { createStackNavigator } from 'react-navigation-stack'

import NavigationBar from '../containers/Navigable/Navigation'
import Chats from '../containers/Navigable/Chats/Chats'
import ChatForm from '../containers/Navigable/Chats/ChatForm'
import Search from '../containers/Navigable/Search/Search'
import Home from '../containers/Navigable/Home/Home'
import LoginScreen from '../containers/Auth/LoginScreen'
import SignUpScreen from '../containers/Auth/SignUpScreen'
import ForgotPassword from '../containers/Auth/ForgotPassword'
import Loading from '../containers/Auth/Loading'
import Settings from '../containers/Navigable/Home/Settings'
import DeleteAccount from '../containers/Navigable/Home/DeleteAccount'
import TermsAndConditions from '../containers/Navigable/Home/TermsOfService'
import PrivacyPolicy from '../containers/Navigable/Home/PrivacyPolicy'
import FirstPage from '../containers/Auth/firstPage'
import EditClasses from '../containers/Navigable/Home/EditClasses'

const AppNavigator = createStackNavigator(
  {
    NavigationBar: {
      screen: NavigationBar,
      navigationOptions: {
        header: null,
      },
    },
    TermsOfService: {
      screen: TermsAndConditions,
      navigationOptions: {
        header: null,
      },
    },
    PrivacyPolicy: {
      screen: PrivacyPolicy,
      navigationOptions: {
        header: null,
      },
    },
    DeleteAccount: {
      screen: DeleteAccount,
      navigationOptions: {
        header: null,
      }
    },
    Settings: {
      screen: Settings,
      navigationOptions: {
        header: null,

      },
      // navigationOption: () => ({
      //   title: 'A',
      //   headerMode: screen,
      //   headerTitleStyle :{color: '#000',textAlign: 'center',alignSelf:'center'},
      //   headerBackTitle: null,
      // }),
    },
    Chats: {
      screen: Chats,
      navigationOptions: {
        header: null,
      },
    },
    ChatForm: {
      screen: ChatForm,
      navigationOptions: {

      },
    },
    Search: {
      screen: Search,
      navigationOptions: {
        header: null,
      },
    },
    Home: {
      screen: Home,
      navigationOptions: {
        header: null,
      },
    },
    FirstPage: {
      screen: FirstPage,
      navigationOptions: {
        header: null,
      },
      animation: 'fade',
    },
    Login: {
      screen: LoginScreen,
      navigationOptions: {
        header: null,
      },
      animation: 'fade',
    },
    SignUp: {
      screen: SignUpScreen,
      navigationOptions: {
        header: null,
      },
    },
    ForgotPassword: {
      screen: ForgotPassword,
      navigationOptions: {
        //     header: null,
      },
    },
    Loading: {
      screen: Loading,
      navigationOptions: {
        header: null,
      },
    },

    EditClasses: {
      screen: EditClasses,
      navigationOptions: {
        header: null,
      },
    },

  },
  {
    initialRouteName: 'Loading',
  }
)

export default createAppContainer(AppNavigator)



import React from 'react';
import { StyleSheet, Text, TextInput, View, Picker, TouchableOpacity } from 'react-native';
import { Button } from 'react-native-elements';
import DatePicker from 'react-native-datepicker';
import firebase from 'react-native-firebase';
const date = new Date().getDate();
const month = new Date().getMonth() + 1;
const year = new Date().getFullYear() - 18;
const max = year + "-" + month + "-" + date;
export default class SignUpForm extends React.Component {
  state = { firstName: '', lastName: '', email: '', date: '', gender: '', password: '', showLoading: false, errorMessage: null, college: '' }
  handleSignUp = () => {
    const {
      firstName,
      lastName,
      email,
      date,
      gender,
      password,
      college
    } = this.state
    this.setState({ showLoading: true })

    var domain = email.replace(/.*@/, "").toLowerCase()
    //console.log("user domain: " + domain)

    if (firstName == '' && lastName == '' && email == '' && date == '' && gender == '' && password == '') {
      this.setState({ showLoading: false, errorMessage: "All fields empty" })
      return 0
    }
    else {
      if (firstName == '') {
        this.setState({ showLoading: false, errorMessage: "Please type your first name" })
        return 0
      }
      if (lastName == '') {
        this.setState({ showLoading: false, errorMessage: "Please type your last name" })
        return 0
      }
      if (date == '') {
        this.setState({ showLoading: false, errorMessage: "Please select your birth date" })
        return 0
      }

      if(college == ''){
        this.setState({ showLoading: false, errorMessage: "Please select your College"})
        return 0
      }

    }

    if (gender == '') {
      this.setState({ showLoading: false, errorMessage: "Please pick a gender" })
      return 0
    }

/*    if (domain !== 'mail.usf.edu') {
      this.setState({ showLoading: false, errorMessage: "Please use your USF Email." })
      return 0
    }*/
    

    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then((cred) => {
        // Add user to collection
        console.log('cred user uid: ', cred.user.uid)
        firebase.firestore().collection("users").doc(cred.user.uid).set({
          firstName,
          lastName,
          email,
          date,
          gender,
          netId: email.substring(0, email.indexOf("@")),
          college
        })
          .then(function () {
            console.log("Document successfully written!");
          })
          .catch(function (error) {
            console.error("Error writing document: ", error);
          })
        var user = firebase.auth().currentUser;
        user.sendEmailVerification().then(function () {
          console.log("email verification sent to user");
        }).catch(function (error) {
          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;

          console.log(errorCode, errorMessage);
        })
        //this.doSendEmailVerification();
        this.props.navigation.navigate('Login')
      })
      .catch(error => this.setState({ showLoading: false, errorMessage: error.message }))
  }
  
  
  render() {
    const { showLoading } = this.state

    colleges = ["University of South Florida", "University of South Florida (Sarasota-Manatee Campus)", "University of South Florida (St. Petersburg Campus)"]

    return (
      <View style={styles.container}>
        <Text style={styles.header}>Sign Up</Text>
        {this.state.errorMessage &&
          <Text style={{ color: 'red' }}>
            {this.state.errorMessage}
          </Text>}
        <TextInput
          placeholder="First Name"
          placeholderTextColor='#0D7AFF'
          autoCapitalize="none"
          maxLength={30}
          style={styles.textInput}
          underlineColorAndroid={'transparent'}
          onChangeText={firstName => this.setState({ firstName })}
          value={this.state.firstName}
        />
        <TextInput
          placeholder="Last Name"
          placeholderTextColor='#0D7AFF'
          autoCapitalize="none"
          maxLength={30}
          style={styles.textInput}
          underlineColorAndroid={'transparent'}
          onChangeText={lastName => this.setState({ lastName })}
          value={this.state.lastName}
        />

        <DatePicker
          style={styles.datePicker}
          date={this.state.date}
          mode="date"
          placeholder="Birthdate"
          placeholderTextColor='#0D7AFF'
          format="YYYY-MM-DD"
          minDate="1900-01-01"
          maxDate={max}
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          customStyles={{
            dateIcon: {
              position: 'absolute',
              left: 0,
              top: 4,
              marginLeft: 0,
              marginBottom: 30,
            },
            dateInput: {
              marginLeft: 20,
              borderWidth: 0,
            },
            dateText: {
              color: '#0D7AFF',
              justifyContent: 'flex-start'
            }
          }}
          onDateChange={date => this.setState({ date })}
        />

        <Picker
          style={styles.genderPicker}
          selectedValue={this.state.gender}
          onValueChange={(itemValue, itemIndex) => this.setState({ gender: itemValue })}>
          <Picker.Item label="Gender" value="" />
          <Picker.Item label="Male" value="male" />
          <Picker.Item label="Female" value="female" />
          <Picker.Item label="Other" value="other" />
        </Picker>

        <Picker
		      style={styles.genderPicker}
		      selectedValue={this.state.college}
		      onValueChange={(itemValue,itemIndex) => this.setState({college: itemValue})}>
		      <Picker.Item label="College" value=""/>
          {colleges.map((item, index) => {
        return (<Picker.Item label={item} value={item} key={index}/>) 
    })}
		    </Picker>

        <TextInput
          placeholder="Email"
          placeholderTextColor='#0D7AFF'
          autoCapitalize="none"
          maxLength={100}
          style={styles.textInput}
          underlineColorAndroid={'transparent'}
          onChangeText={email => this.setState({ email })}
          value={this.state.email}
        />
        <TextInput
          secureTextEntry
          placeholder="Password"
          placeholderTextColor='#0D7AFF'
          autoCapitalize="none"
          maxLength={30}
          style={styles.textInput}
          underlineColorAndroid={'transparent'}
          onChangeText={password => this.setState({ password })}
          value={this.state.password}
        />
        {/* <Button
          title="Sign Up"
          type="solid"
          loading={showLoading}
          buttonStyle={styles.button}
          onPress={this.handleSignUp}
          >
        </Button> */}

        <TouchableOpacity style={styles.button1}
          onPress={this.handleSignUp}>
          <Text style={styles.signinText}>REGISTER</Text>
        </TouchableOpacity>


        <Text style={styles.signupText} onPress={() => this.props.navigation.navigate('Login')}>Already have an account? Login</Text>
      </View>
    )
  }
}
const styles = StyleSheet.create({
  container: {
    alignSelf: 'stretch',
    // paddingTop:10,
    // paddingBottom: 10
  },
  genderPicker: {
    width: '106%',
    color: '#0D7AFF',
    padding: 0,
    //height: 60,
    //marginRight: 36,
    marginBottom: 10,
    borderBottomColor: '#0D7AFF',
    borderBottomWidth: 1
  },
  datePicker: {
    alignSelf: 'stretch',
    width: 270,
    padding: 0,
    marginRight: 36,
    marginBottom: 25,
    borderBottomColor: '#0D7AFF',
    borderBottomWidth: 1
  },
  header: {
    fontSize: 24,
    color: '#FE4642',
    paddingBottom: 10,
    marginBottom: 40,
    borderBottomColor: '#FE4642',
    borderBottomWidth: 1
  },
  textInput: {
    alignSelf: 'stretch',
    height: 40,
    marginBottom: 30,
    color: '#0D7AFF',
    borderBottomColor: '#0D7AFF',
    borderBottomWidth: 1
  },
  text: {
    alignSelf: 'stretch',
    height: 40,
    color: '#0D7AFF',
  },
  button: {
    alignSelf: 'stretch',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#59cbbd',
    marginTop: 30,
    marginBottom: 30
  },
  btntext: {
    color: '#0D7AFF',
    fontWeight: 'bold',
  },
  signupText: {
    color: '#0D7AFF',
    backgroundColor: 'transparent',
    textAlign: 'center'
  },

  button1: {
    alignSelf: 'stretch',
    alignItems: 'center',
    backgroundColor: '#FE4642',
    marginBottom: 10,
    borderRadius: 18,
    height: 55,
  },

 signinText: {
    color: "#fff",
    justifyContent: 'center',
    textAlign: 'center',
    fontSize: 20,
    paddingTop: 15,
    // paddingBottom: 10,
    fontWeight: "bold",
  }
})
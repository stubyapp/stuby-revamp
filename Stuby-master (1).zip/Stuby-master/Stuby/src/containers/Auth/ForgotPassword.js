import React from 'react'
import { StyleSheet, Text, TextInput, View, ImageBackground, TouchableOpacity } from 'react-native'
import firebase from 'react-native-firebase'

import { Button } from 'react-native-elements';

export default class SignUpForm extends React.Component {
	state = { email: '', showLoading: false, errorMessage: null }
  
  static navigationOptions = ({ navigation }) => ({
    headerTintColor: '#fff',
    headerStyle: {
      backgroundColor: '#0D7AFF'
      //backgroundColor: '#59cbbd'
    },
    // headerTitleStyle: {
    //   color: '#fff'
    // }
  });

	handleForgotPassword = () => {

    this.setState({showLoading: true})

    firebase
      .auth()
      .sendPasswordResetEmail(this.state.email)
      .then(() => {
        alert("Please check your email!!!")
        this.props.navigation.navigate('Login')})
      .catch(error => this.setState({ errorMessage: error.message }))
	}
	
  render() {
    return (

      <View>
        <ImageBackground source={require('../../assets/images/backgroundDone.png')} style={{width: '100%',height:'100%' }}>
 
      <View style={styles.container}>
        
        <Text style={styles.header}>Forgot Password</Text>
        {this.state.errorMessage &&
          <Text style={{ color: 'red' }}>
            {this.state.errorMessage}
          </Text>}
        <TextInput
          placeholder="Email"
          placeholderTextColor='grey'
          autoCapitalize="none"
          style={styles.textInput}
          underlineColorAndroid={'transparent'}
          onChangeText={email => this.setState({ email })}
          value={this.state.email}
        />
        {/* <Button
          title="Verify"
          type="solid"
          loading={this.state.showLoading}
          buttonStyle={styles.button}
          onPress={this.handleForgotPassword}
        >
        </Button> */}

        <TouchableOpacity style={styles.button} onPress={this.handleForgotPassword}>
          <Text style={styles.signinText}>LOGIN</Text>
        </TouchableOpacity>



       
      </View>
      </ImageBackground>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    alignSelf: 'stretch',
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff00',
    paddingLeft: 60,
    paddingRight: 60,
  },
  header: {
    fontSize: 24,
    color: '#0D7AFF',
    paddingBottom: 10,
    marginBottom: 40,
    borderBottomColor: '#0D7AFF',
    borderBottomWidth: 1,
  },
  textInput: {
    fontSize: 18,
    alignSelf: 'stretch',
    height: 40,
    marginBottom: 30,
    color: 'grey',
    borderBottomColor: 'grey',
    borderBottomWidth: 1
  },
  button: {
    alignSelf: 'stretch',
    alignItems: 'center',
    backgroundColor: '#0D7AFF',
    marginTop: 20,
    borderRadius: 18,
    height: 55,
    shadowColor: 'white',
    shadowOpacity: 0.8,
    shadowRadius: 15,
    shadowOffset: { width: 56, height: 13 },

  },
  btntext: {
    color: '#fff',
    fontWeight: 'bold',
  },

  signinText: {
    color: "#fff",
    justifyContent: 'center',
    textAlign: 'center',
    fontSize: 20,
    paddingTop: 15,
    // paddingBottom: 20,
    fontWeight: "bold",
  }
})
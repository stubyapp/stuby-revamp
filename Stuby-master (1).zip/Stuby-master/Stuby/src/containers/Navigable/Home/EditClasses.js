import React, { Component } from 'react';
import Dimensions from 'Dimensions';
import PropTypes from 'prop-types';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import ImagePicker from 'react-native-image-picker';
import firebase from 'react-native-firebase';
import defaultPic from '../../../assets/images/logo.png'
import firebaseSDK from '../../../config/firebaseSDK';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Alert,
  Button,
  ImageBackground,
  KeyboardAvoidingView,
  TouchableOpacity,
  TextInput,
  CheckBox,
} from 'react-native';
import { Avatar } from "react-native-elements"
import logo from "../../../assets/images/click_to_add.png";
import logoImg from '../../../assets/images/logo-full-color__1_.png';

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

export default class EditClasses extends Component {
  constructor(props) {
    super(props);
    this.state = {
      major: '',
      study: ''
    }
  }


  next() {
    let { major, study } = this.state
    let nextValue = {
      major,
      study
    }
    console.log(nextValue, 'value');
  }

  render() {

    return (
      // <View style={styles.container}>     
      <View style={{ flex: 1 }}>
        <ImageBackground source={require('../../../assets/images/backgroundDone.png')} style={{ width: '100%', height: '100%' }}>

          <View style={{ flexDirection: 'row', height: 70, backgroundColor: '#fff', borderBottomWidth: 2, borderBottomColor: "#d3d3d3" }} >
            <View style={{ flex: 1, justifyContent: 'center' }} >
              <TouchableOpacity style={styles.backButton} onPress={() => (this.props.navigation.navigate('Settings'))}>
                <Text style={{ color: '#D71760', alignItems: 'center', justifyContent: 'center' }}>Back</Text>
              </TouchableOpacity>
            </View>
            <View style={{ flex: 3, alignItems: "center", justifyContent: "center" }} >
              <Image source={logoImg} style={{ width: 150, height: 50, }} />

            </View>
          </View>

          <View style={{
            borderRadius: 60,
            borderColor: "#D71760",
            borderWidth: 3,
            height: 110,
            width: "80%",
            marginLeft: "10%",
            marginTop: "5%",
            backgroundColor: "#fff",
            flexDirection: "row"
          }} >

            <View style={{ flex: 1.5, marginTop: "13%", marginLeft: '5%' }}>
              <Text style={{ fontSize: 18 }}>Major:</Text>

            </View>
            <View style={{ flex: 2.5, marginTop: "8%", marginRight: "25%" }}>
              <TextInput style={{ width: 150, height: 45, borderBottomColor: '#d3d3d3', borderBottomWidth: 2 }}
                onChangeText={(text) => this.setState({ major: text })}
              >

              </TextInput>
            </View>
          </View>

          <View style={{
            borderRadius: 60,
            borderColor: "#D71760",
            borderWidth: 3,
            height: 250,
            width: "80%",
            marginLeft: "10%",
            marginTop: "5%",
            backgroundColor: "#fff",
            flexDirection: "row"
          }} >

            <View style={{ padding: 20, }}>
              <Text style={{ fontSize: 20, textAlign: "center", marginTop: "2%" }}>What class would you like a study buddy for?</Text>
              <View style={{ flexDirection: "row" }}>
                <View style={{ marginTop: "13%", marginLeft: '5%', }}>
                  <Text style={{ fontSize: 20 }}>1.</Text>

                </View>
                <View style={{ flex: 2.5, marginTop: "8%", alignItems: "center" }}>
                  <TextInput style={{ width: 150, height: 45, borderBottomColor: '#d3d3d3', borderBottomWidth: 2 }}
                    onChangeText={(text) => this.setState({ study: text })}
                  >

                  </TextInput>
                </View>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "center", marginTop: "17%" }} >
                <TouchableOpacity style={styles.addButton} onPress={() => this.next()}>
                  <Text style={{ color: '#0D7AFF', textAlign: 'center', }}>Add</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.deleteButton} onPress={() => { alert('working'); }}>
                  <Text style={{ color: '#D71760', textAlign: 'center', }}>Delete</Text>
                </TouchableOpacity>
              </View>

            </View>







          </View>
          <View style={{ marginTop: "20%" }}>

          </View>
          <View style={{ flexDirection: "row-reverse", }}>
            <TouchableOpacity style={styles.addButton} onPress={() => { alert('working'); }}>
              <Text style={{ color: '#0D7AFF', textAlign: 'center', paddingBottom: 7, fontSize: 18 }}>Next</Text>
            </TouchableOpacity>
          </View>
          <View style={{ marginTop: "10%" }}>

          </View>


        </ImageBackground>
        {/* </View> */}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#36485f',
    height: DEVICE_HEIGHT,
  },
  textBox: {
    marginTop: 10,
    alignItems: 'center',
    color: '#fff',
  },
  SelectImgButton: {
    backgroundColor: 'grey',
    margin: 10,
    padding: 10,
  },

  SelectImage: {
    color: "#fff"
  },
  header: {
    // backgroundColor: "#59cbbd",
    marginTop: "5%",
    height: 40,
    alignItems: 'center'
  },
  boxes: {
    marginTop: 10,
    alignItems: 'center',
    color: '#fff',
  },
  avatar: {
    width: 10,
    height: 10,
    borderRadius: 63,
    borderWidth: 0,
    alignSelf: 'center',
    position: 'absolute',
    zIndex: 106,
  },
  avatar2: {
    width: 125,
    height: 125,
    borderRadius: 63,
    borderWidth: 0,
    alignSelf: 'center',
    position: 'absolute',
    zIndex: 105,
  },
  avatar3: {
    borderRadius: 100,
    overflow: "hidden",
    width: 135,
    height: 135,
    // borderRadius: 63,
    //borderWidth: 0,
    //borderColor: "white",
    alignSelf: 'center',
    position: 'absolute',
    marginTop: 120,
    //zIndex: 104,
  },
  lookingFor: {
    fontSize: 20,
    color: "#FFFFFF",
    fontWeight: '300',
  },
  body: {
    marginTop: 170,
  },
  bodyContent: {
    flex: 1,
    alignItems: 'center',
    padding: 30,
    // marginBottom: "10%"
  },
  name: {
    fontSize: 20,
    color: "white",
    fontWeight: "600"
  },
  info: {
    fontSize: 16,
    color: "#59cbbd",
    // marginTop: 10,
    // marginBottom: 50,
  },
  buttonContainer: {
    marginTop: 15,
    height: 45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    width: 240,
    borderRadius: 30,
    backgroundColor: "#D71760",
  },
  UpdatePicture: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    borderColor: '#0D7AFF',
    borderWidth: 1.5,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10
  },
  logo: {
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 50,
  },
  backButton: {

    borderRadius: 25,
    borderColor: '#D71760',
    borderWidth: 2,
    padding: 5,
    marginLeft: 10,
    alignItems: "center"

  },
  addButton: {
    borderRadius: 25,
    borderColor: '#0D7AFF',
    borderWidth: 2,
    width: 80,
    paddingTop: 7,
    marginRight: "15%"
  },
  deleteButton: {
    borderRadius: 25,
    borderColor: '#D71760',
    borderWidth: 2,
    width: 70,
    paddingTop: 7,
    marginLeft: "15%",
  }
})


import React from 'react';
import ReactNativeSettingsPage, {
  SectionRow,
  NavigateRow,
  CheckRow
} from 'react-native-settings-page';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  ImageBackground,
  KeyboardAvoidingView,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Picker,
} from 'react-native';
import { Container, Header, Content, ListItem, Radio, Right, Left, CheckBox, Body, Textarea } from 'native-base';
// import { Container, Header, Content, ListItem, CheckBox, Text, Body } from 'native-base';
// import RadioForm, { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';
import Dimensions from 'Dimensions';
import OptionsMenu from "react-native-options-menu";
import firebase from 'react-native-firebase';
import firebaseSDK from '../../../config/firebaseSDK';
// import Textarea from 'react-native-textarea';
import logoImg from '../../../assets/images/logo-full-color__1_.png';


const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;
const config = {
  apiKey: "AIzaSyA7rKxumJ8voSTMbroG53g7imAm5Mul1Gw",
  authDomain: "stuby-341c5.firebaseio.com",
  storageBucket: "stuby-341c5.appspot.com",
}
firebase.initializeApp(config)


export default class Settings extends React.Component {

  static navigationOptions = () => ({
    title: 'Settings',
  });

  // TODO: implement your navigationOptions
  state = {
    dates: false,
    friends: false,
    studybuddies: false,
    college: "",
    major: "",
    men: false,
    women: false,
    other: false,
    loaded: false,
    userName: 'Anna`s Bio',
    gpaText: '',
    persolanInfo: '',
    display: false,
    partnerStyle: {
      QuietStudier: true, PreferCollaboration: false,
    },
    preferredStudyLocation: {
      OnCampus: true, OffCampus: false,
    },
    preferredStudyTime: {
      NightOwl: true, DayDriven: false,
    },
    gender: {
      male: true, female: false, preferNotToSay: false
    },
    interest: {
      hereToPass: true, wantsAnAorB: false
    }

  }
  componentDidMount() {
    //console.log('componentDidMount current uid: ', firebaseSDK.shared.uid)
    this.unsubscribe = firebase
      .firestore().collection("users").doc(firebaseSDK.shared.uid)
      .onSnapshot((doc) => {
        //console.log('doc data:', doc.data())
        const data = doc.data()
        if (data != undefined) {
          this.setState({
            dates: data.dates,
            friends: data.friends,
            studybuddies: data.studybuddies,
            men: data.menPref,
            women: data.womenPref,
            other: data.otherPref,
            college: data.college,
            major: data.major,
          })
        }
      })
  }

  componentWillUnmount() {
    console.log("component will unmount called")
    this.unsubscribe();
  }
  _navigateToScreen = () => {
    const { navigation } = this.props.navigation.navigate('DeleteAccount');
  }
  _navigateToPrivacy = () => {
    const { navigation } = this.props.navigation.navigate('PrivacyPolicy');
  }
  _navigateToTerms = () => {
    const { navigation } = this.props.navigation.navigate('TermsOfService');
  }
  CheckboxDates() {
    this.setState({ dates: !this.state.dates })

    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      dates: !this.state.dates,
    }, { merge: true })
      .then(function () {
        // console.log('current uid: ', firebaseSDK.shared.uid);
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }

  CheckboxFriends() {
    this.setState({ friends: !this.state.friends })

    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      friends: !this.state.friends,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });

  }
  CheckboxStudyBuddies() {
    this.setState({ studybuddies: !this.state.studybuddies })

    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      studybuddies: !this.state.studybuddies,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }
  CheckboxMen() {
    this.setState({ men: !this.state.men })

    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      menPref: !this.state.men,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }
  CheckboxWomen() {
    this.setState({ women: !this.state.women })
    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      womenPref: !this.state.women,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }
  CheckboxOther() {
    this.setState({ other: !this.state.other })
    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      otherPref: !this.state.other,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }
  onChangeCollege = (itemValue) => {
    this.setState({ college: itemValue })
    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      college: itemValue,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }
  onChangeMajor = (text) => {
    this.setState({ major: text });
    firebase.firestore().collection("users").doc(firebaseSDK.shared.uid).set({
      major: text,
    }, { merge: true })
      .then(function () {
        console.log("Document successfully written!");
      })
      .catch(function (error) {
        console.error("Error writing document: ", error);
      });
  }


  patnerStyle(Unit) {

    this.setState({
      partnerStyle: { QuietStudier: false, PreferCollaboration: false, }
    }, () => {
      let { partnerStyle } = this.state
      let valueClone = partnerStyle
      valueClone[Unit] = true
      this.setState({
        partnerStyle: valueClone
      })

    })
  }

  preferredStudyLocation(Unit) {
    this.setState({
      preferredStudyLocation: { OnCampus: false, OffCampus: false, }
    }, () => {
      let { preferredStudyLocation } = this.state
      let valueClone = preferredStudyLocation
      valueClone[Unit] = true
      this.setState({
        preferredStudyLocation: valueClone
      })
      console.log(valueClone);

    })
  }


  preferredStudyTime(Unit) {
    this.setState({
      preferredStudyTime: { NightOwl: false, DayDriven: false, }
    }, () => {
      let { preferredStudyTime } = this.state
      let valueClone = preferredStudyTime
      valueClone[Unit] = true
      this.setState({
        preferredStudyTime: valueClone
      })
      console.log(valueClone);

    })
  }

  gender(Unit) {
    this.setState({
      gender: { male: false, female: false, preferNotToSay: false }
    }, () => {
      let { gender } = this.state
      let valueClone = gender
      valueClone[Unit] = true
      this.setState({
        gender: valueClone
      })
      console.log(valueClone);

    })
  }

  interest(Unit) {
    this.setState({
      interest: { hereToPass: false, wantsAnAorB: false }
    }, () => {
      let { interest } = this.state
      let valueClone = interest
      valueClone[Unit] = true
      this.setState({
        interest: valueClone
      })
      console.log(valueClone);

    })
  }

  display() {
    let { display } = this.state
    if (display === true) {
      this.setState({
        display: false
      },
        () => {

        })
    }
    if (display === false) {
      this.setState({
        display: true
      }, () => {

      })
    }
  }



  done() {
    let { partnerStyle, preferredStudyLocation, preferredStudyTime, gender, interest, gpaText, display, persolanInfo } = this.state

    let addValue = {
      partnerStyle,
      preferredStudyLocation,
      preferredStudyTime,
      gender,
      interest,
      gpaText,
      display,
      persolanInfo
    }
    console.log(addValue);
  }





  render() {
    let { partnerStyle, preferredStudyLocation, preferredStudyTime, gender, interest, display, gpaText, persolanInfo } = this.state
    // console.log(partnerStyle, 'partnerStyle');

    return (
      // <ReactNativeSettingsPage>

      //   <SectionRow text='Preferences'>
      //     <CheckRow
      //       text='Search for Study Buddies'
      //       iconName='book'
      //       _color='#000'
      //       _value={this.state.studybuddies}
      //       _onValueChange={() => { this.CheckboxStudyBuddies() }} />
      //     <CheckRow
      //       text='Search for Friends'
      //       iconName='handshake-o'
      //       _color='#000'
      //       _value={this.state.friends}
      //       _onValueChange={() => { this.CheckboxFriends() }} />
      //     <CheckRow
      //       text='Search for Dates'
      //       iconName='heart'
      //       _color='#000'
      //       _value={this.state.dates}
      //       _onValueChange={() => { this.CheckboxDates() }} />
      //   </SectionRow>
      //   {(this.state.studybuddies) && <SectionRow text='Studying'>
      //     <Picker
      //       style={styles.picker}
      //       selectedValue={this.state.college}
      //       onValueChange={(itemValue, itemIndex) => (this.onChangeCollege(itemValue))}>
      //       <Picker.Item label="Select Department" value="" />
      //       <Picker.Item label="College of Arts" value="College of Arts" />
      //       <Picker.Item label="College of Arts and Sciences" value="College of Arts and Sciences" />
      //       <Picker.Item label="College of Behavioral and Community Sciences" value="College of Behavioral and Community Sciences" />
      //       <Picker.Item label="College of Business" value="College of Business" />
      //       <Picker.Item label="College of Education" value="College of Education" />
      //       <Picker.Item label="College of Engineering" value="College of Engineering" />
      //       <Picker.Item label="College of Global Sustainability" value="College of Global Sustainability" />
      //       <Picker.Item label="College of Marine Science" value="College of Marine Science" />
      //       <Picker.Item label="College of Medicine" value="College of Medicine" />
      //       <Picker.Item label="College of Nursing" value="College of Nursing" />
      //       <Picker.Item label="College of Pharmacy" value="College of Pharmacy" />
      //       <Picker.Item label="College of Public Health" value="College of Public Health" />
      //     </Picker>
      //     <TextInput
      //       placeholder="Major"
      //       placeholderTextColor='black'
      //       autoCapitalize="none"
      //       style={styles.textInput}
      //       underlineColorAndroid={'transparent'}
      //       defaultValue={this.state.major}
      //       onChangeText={(text) => this.onChangeMajor(text)}
      //       maxLength={100} /></SectionRow>}
      //   {(this.state.dates) && <SectionRow text="Dating">
      //     <CheckRow
      //       text='Search for Men'
      //       iconName='male'
      //       _color='#000'
      //       _value={this.state.men}
      //       _onValueChange={() => { this.CheckboxMen() }} />
      //     <CheckRow
      //       text='Search for Women'
      //       iconName='female'
      //       _color='#000'
      //       _value={this.state.women}
      //       _onValueChange={() => { this.CheckboxWomen() }} />
      //     <CheckRow
      //       text='Search for Other'
      //       iconName='transgender-alt'
      //       _color='#000'
      //       _value={this.state.other}
      //       _onValueChange={() => { this.CheckboxOther() }} />
      //   </SectionRow>}
      //   <SectionRow text="Account">
      //     <NavigateRow text="Terms of Service"
      //       iconName={'paperclip'}
      //       onPressCallback={() => { this._navigateToTerms() }} />
      //     <NavigateRow text="Privacy Policy"
      //       iconName={'user-secret'}
      //       onPressCallback={() => { this._navigateToPrivacy() }} />
      //     <NavigateRow text="Delete Account"
      //       iconName={'trash'}
      //       onPressCallback={() => { this._navigateToScreen() }} />
      //   </SectionRow>
      // </ReactNativeSettingsPage>

      <ImageBackground source={require('../../../assets/images/backgroundDone.png')} style={{ width: '100%', height: '100%' }}>


        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', height: 70, backgroundColor: '#fff', borderBottomWidth: 2, borderBottomColor: "#d3d3d3" }} >
            <View style={{ flex: 1, justifyContent: 'center' }} >
              <TouchableOpacity style={styles.backButton} onPress={() => (this.props.navigation.navigate('Home'))}>
                <Text style={{ color: '#D71760', alignItems: 'center', justifyContent: 'center' }}>Back</Text>
              </TouchableOpacity>
            </View>
            <View style={{ flex: 3, alignItems: "center", justifyContent: "center" }} >
              <Image source={logoImg} style={{ width: 150, height: 50, }} />

            </View>
          </View>
          <ScrollView style={{ marginTop: "5%", marginBottom: "2%" }}>
            <View style={{ flexDirection: "row", width: '90%', }}>
              <View style={{ flex: 2.5, alignItems: 'center', justifyContent: "center" }}>
                <Text style={{ fontSize: 25, color: '#0D7AFF' }}>{this.state.userName}</Text>
              </View>

              <View style={{ flex: 1, justifyContent: "center", }}>
                <View style={{ height: 100, width: 100, }}>
                  <Image style={{
                    height: 100, width: 100,
                    borderRadius: 100,
                    overflow: "hidden",
                  }}
                    source={require('../../../assets/images/click_to_add.png')} />
                </View>


              </View>



            </View>

            <View style={{ flexDirection: "row-reverse", marginLeft: '7%', marginTop: '2%' }}>
              <TouchableOpacity style={styles.UpdatePicture} onPress={() => { alert("working") }}>
                <Text style={{ color: '#0D7AFF', alignItems: 'center', paddingBottom: 22 }}>Update Picture</Text>
              </TouchableOpacity>
            </View>

            <View style={{ flex: 1, marginLeft: "7%" }}>
              <View style={{ flex: 1, }}>

                <TouchableOpacity style={styles.buttonContainer} onPress={() => (this.props.navigation.navigate('EditClasses'))}>
                  <Text style={{ color: '#fff', fontWeight: "bold", fontSize: 18 }}>Edit Classes</Text>
                </TouchableOpacity>
              </View>

              <View style={{ flex: 1, width: '90%', marginTop: "2.5%" }}>
                <View style={{ marginLeft: "4%" }}>
                  <Text style={{ color: '#0D7AFF', fontSize: 20, fontWeight: "bold" }}>Partner Style</Text>

                </View>
                <View style={{ marginLeft: "-5%", }}>


                  <View>
                    {/* <TouchableOpacity onPress={() => alert('ddddd')} > */}
                    <ListItem style={styles.radioButton} onPress={() => { this.patnerStyle("QuietStudier") }}>
                      <Left >
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Quiet Studier</Text>
                      </Left>
                      <Right>
                        <Radio selected={partnerStyle.QuietStudier} />
                      </Right>
                    </ListItem>
                    {/* </TouchableOpacity> */}
                  </View>

                  <View>

                    <ListItem style={styles.radioButton2} onPress={() => { this.patnerStyle("PreferCollaboration") }}>
                      <Left>
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Prefer Collaboration</Text>
                      </Left>
                      <Right>
                        <Radio selected={partnerStyle.PreferCollaboration} />
                      </Right>
                    </ListItem>
                  </View>

                </View>

              </View>


              <View style={{ flex: 1, width: '90%', marginTop: "2.5%" }}>
                <View style={{ marginLeft: "4%" }}>
                  <Text style={{ color: '#0D7AFF', fontSize: 20, fontWeight: "bold" }}>Preferred Study Location</Text>

                </View>
                <View style={{ marginLeft: "-5%", }}>

                  <ListItem style={styles.radioButton} onPress={() => { this.preferredStudyLocation("OnCampus") }}>
                    <Left >
                      <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>On Campus</Text>
                    </Left>
                    <Right>
                      <Radio selected={preferredStudyLocation.OnCampus} />
                    </Right>
                  </ListItem>
                  <ListItem style={styles.radioButton2} onPress={() => { this.preferredStudyLocation("OffCampus") }}>
                    <Left>
                      <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Off Campus</Text>
                    </Left>
                    <Right>
                      <Radio selected={preferredStudyLocation.OffCampus} />
                    </Right>
                  </ListItem>
                </View>

              </View>



              <View style={{ flex: 1, width: '90%', marginTop: "2.5%" }}>
                <View style={{ marginLeft: "4%" }}>
                  <Text style={{ color: '#0D7AFF', fontSize: 20, fontWeight: "bold" }}>Preferred Study Time</Text>

                </View>
                <View style={{ marginLeft: "-5%", }}>
                  <View>
                    <ListItem style={styles.radioButton} onPress={() => { this.preferredStudyTime("NightOwl") }}>
                      <Left >
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Night Owl</Text>
                      </Left>
                      <Right>
                        <Radio selected={preferredStudyTime.NightOwl} />
                      </Right>
                    </ListItem>
                  </View>

                  <View>
                    <ListItem style={styles.radioButton2} onPress={() => { this.preferredStudyTime("DayDriven") }}>
                      <Left>
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Day Driven</Text>
                      </Left>
                      <Right>
                        <Radio selected={preferredStudyTime.DayDriven} />
                      </Right>
                    </ListItem>
                  </View>
                </View>

              </View>


              <View style={{ flex: 1, width: '90%', marginTop: "2.5%" }}>
                <View style={{ marginLeft: "4%" }}>
                  <Text style={{ color: '#0D7AFF', fontSize: 20, fontWeight: "bold" }}>Gender</Text>

                </View>
                <View style={{ marginLeft: "-5%", }}>
                  <View>
                    <ListItem style={styles.radioButton} onPress={() => { this.gender("male") }}>
                      <Left >
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Male</Text>
                      </Left>
                      <Right>
                        <Radio selected={gender.male} />
                      </Right>
                    </ListItem>
                  </View>

                  <View>
                    <ListItem style={styles.radioButton2} onPress={() => { this.gender("female") }}>
                      <Left>
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Female</Text>
                      </Left>
                      <Right>
                        <Radio selected={gender.female} />
                      </Right>
                    </ListItem>
                  </View>

                  <View>
                    <ListItem style={styles.radioButton2} onPress={() => { this.gender("preferNotToSay") }}>
                      <Left>
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Prefer not to say</Text>
                      </Left>
                      <Right>
                        <Radio selected={gender.preferNotToSay} />
                      </Right>
                    </ListItem>
                  </View>
                </View>

              </View>

              <View style={{ marginLeft: "4%", marginTop: '10%' }}>
                <Text style={{ color: '#0D7AFF', fontSize: 20, fontWeight: "bold" }}>GPA</Text>
                <View style={{ flex: 4, flexDirection: "row" }}>
                  <View style={{ flex: 1, }}>
                    <TextInput style={{ width: "80%", height: 45, backgroundColor: '#fff', borderColor: 'black', borderWidth: 1 }}
                      onChangeText={(text) => this.setState({ gpaText: text })}
                    >

                    </TextInput>
                  </View>
                  <View style={{ flex: 2.5, }}>
                    <Content>
                      <ListItem style={{ marginLeft: "0%" }} onPress={() => { this.display() }}>
                        <CheckBox checked={display} />
                        <Body>
                          <Text style={{ color: '#0D7AFF', fontSize: 12, }}>*Do not display to others</Text>
                        </Body>
                      </ListItem>

                    </Content>
                  </View>
                </View>

              </View>

              <View style={{ flex: 1, width: '90%', marginTop: "2.5%" }}>
                <View style={{ marginLeft: "4%" }}>
                  <Text style={{ color: '#0D7AFF', fontSize: 20, fontWeight: "bold" }}>Interest</Text>

                </View>
                <View style={{ marginLeft: "-5%", }}>
                  <View>
                    <ListItem style={styles.radioButton} onPress={() => { this.interest("hereToPass") }} >
                      <Left >
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Here to pass</Text>
                      </Left>
                      <Right>
                        <Radio selected={interest.hereToPass} />
                      </Right>
                    </ListItem>
                  </View>
                  <View>

                    <ListItem style={styles.radioButton2} onPress={() => { this.interest("wantsAnAorB") }}>
                      <Left>
                        <Text style={{ paddingLeft: 15, color: '#fff', fontWeight: "bold" }}>Wants an A or B</Text>
                      </Left>
                      <Right>
                        <Radio selected={interest.wantsAnAorB} />
                      </Right>
                    </ListItem>
                  </View>
                </View>

              </View>



              <View style={{ marginTop: '10%', marginBottom: '12%' }}>

                <Textarea
                  borderRadius={25}
                  borderWidth={2}
                  borderColor="#d3d3d3"
                  backgroundColor="#fff"
                  marginRight={25}
                  rowSpan={5}
                  onChangeText={(text) => this.setState({ persolanInfo: text })}
                // value={}
                />
                <Text style={{ marginTop: "-12%", marginLeft: "45%", fontSize: 20, color: "#87ceeb" }} >Personal Info</Text>

              </View>

              <View style={{ flexDirection: "row-reverse", marginLeft: "3%" }}>
                <TouchableOpacity style={styles.doneButton} onPress={() => this.done()}>
                  <Text style={{ color: '#0D7AFF', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>Done</Text>
                </TouchableOpacity>
              </View>
              <View style={{ marginTop: "10%" }}>

              </View>





            </View>
          </ScrollView>
        </View>
      </ImageBackground>






    )
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#36485f',
  },
  textInput: {
    alignSelf: 'center',
    alignItems: 'center',
    marginBottom: 30,
    color: 'black',
    width: DEVICE_WIDTH - DEVICE_WIDTH * 0.135,
    borderBottomColor: 'black',
    borderBottomWidth: 1
  },
  picker: {
    width: DEVICE_WIDTH - DEVICE_WIDTH * 0.1,
    color: 'black',
    padding: 0,
    height: 60,
    //marginRight: 36,
    marginBottom: 10,
    borderBottomColor: '#f8f8f8',
    borderBottomWidth: 1,
    alignSelf: 'center',
    alignItems: 'center',
  },
  textBox: {
    marginTop: 10,
    color: '#fff',
    alignSelf: 'center',
  },
  boxes: {
    marginTop: 10,
    color: '#fff',
    alignSelf: 'center',
  },
  lookingFor: {
    fontSize: 20,
    color: "#FFFFFF",
    fontWeight: '300',
  },
  avatar: {
    width: 130,
    height: 130,
    borderRadius: 63,
    borderWidth: 4,
    borderColor: "white",
    alignSelf: 'center',
    position: 'absolute',
    zIndex: 108,
  },
  avatar2: {
    width: 130,
    height: 130,
    borderRadius: 63,
    borderWidth: 4,
    borderColor: "white",
    alignSelf: 'center',
    position: 'absolute',
    marginTop: 80,
    zIndex: 107,
  },
  avatar3: {
    borderRadius: 100,
    overflow: "hidden",
    width: 135,
    height: 135,
    // borderRadius: 63,
    //borderWidth: 0,
    //borderColor: "white",
    alignSelf: 'center',
    position: 'absolute',
    marginTop: 120,
    //zIndex: 104,
  },

  UpdatePicture: {

    borderRadius: 25,
    borderColor: '#0D7AFF',
    borderWidth: 1.5,
    padding: 5,

  },

  buttonContainer: {
    marginTop: 15,
    height: 45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    width: 270,
    borderRadius: 15,
    borderColor: '#0D7AFF',
    borderWidth: 2,
    backgroundColor: "#D71760",
  },
  checkBox: {
    marginBottom: 15,
    width: 240,
    borderRadius: 15,
    backgroundColor: "#D71760",
  },
  radioButton: {
    marginTop: 15,
    height: 45,
    // flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    // marginBottom: 15,
    width: 270,
    borderRadius: 15,
    // borderColor: '#0D7AFF',
    // borderWidth: 2,
    backgroundColor: "#D71760",
  },
  radioButton2: {
    marginTop: 15,
    height: 45,
    // flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    // marginBottom: 15,
    width: 270,
    borderRadius: 15,
    // borderColor: '#0D7AFF',
    // borderWidth: 2,
    backgroundColor: "#d3d3d3",
  },
  backButton: {

    borderRadius: 25,
    borderColor: '#D71760',
    borderWidth: 2,
    padding: 5,
    marginLeft: 10,
    alignItems: "center"

  },
  container: {
    flex: 1,
    paddingHorizontal: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },

  doneButton: {
    width: 80,
    borderRadius: 25,
    backgroundColor: '#fff',
    // borderWidth: 2,
    padding: 5,
    marginLeft: 10,
    alignItems: "center"

  }
})